# 目标检测(Object Detection)
目标检测是计算机视觉中最基础也是最难的任务之一，尤其是通用目标检测。

# 论文阅读及理解
[ACMMM2019 Draft] Small and Dense Commodity Object Detection with Multi-Receptive Field Attention [[理解]](./acmmm2019_SDCOD/acmmm2019_SDCOD.md) 