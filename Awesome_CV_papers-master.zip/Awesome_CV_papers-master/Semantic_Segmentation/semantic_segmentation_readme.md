# 语义分割(Semantic Segmentation)

# 论文阅读及理解
[CVPR2019] Dual Attention Network for Scene Segmentation [[理解]](./cvpr2019_DANet/cvpr2019_DANet.md) 