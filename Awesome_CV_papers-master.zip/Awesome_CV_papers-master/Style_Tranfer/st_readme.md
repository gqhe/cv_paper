# 风格迁移(Style Transfer)
风格迁移：莫奈转成毕加索，斑马转成马，猫转成狗。

# 论文阅读及理解
[Arxiv2019] TraVeLGAN: Image-to-image Translation by Transformation Vector Learning
[ICLR2019] INSTAGAN:INSTANCE-AWARE IMAGE-TO-IMAGE TRANSLATION  
[AAAI2019] Guiding the One-to-one Mapping in CycleGAN via Optimal Transport  
[ECCV2018] Unsupervised Image-to-Image Translation with Stacked Cycle-Consistent Adversarial Networks  
[ICCV2017] Unpaired Image-to-Image Translation using Cycle-Consistent Adversarial Networks  
[CVPR2017] Image-to-Image Translation with Conditional Adversarial Networks