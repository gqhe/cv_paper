# 行人行为理解(People Behavior Understanding)
行人行为理解：分析、预测行人轨迹；场景集聚度度量

# 论文阅读及理解
[AAAI2018] Understanding Human Behaviors in Crowds by Imitating the Decision-Making Process  
[ECCV2016] Pedestrian Behavior Understanding and Prediction with Deep Neural Networks  
[TIP-2016] Pedestrian Behavior Modeling From Stationary  
[CVPR2015] Understanding Pedestrian Behaviors from Stationary Crowd Groups  
[PAMI2013] Measuring Crowd Collectiveness
