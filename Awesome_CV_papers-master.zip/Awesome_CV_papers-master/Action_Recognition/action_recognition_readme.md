# 动作识别(Action Recognition)

# 论文阅读及理解
[ACMMM2019 Draft] Enhancing Accuracy of Deep Action Recognition through Intelligent Fusion of Video and Smart Glove Data
 [[理解]](./acmmm2019_EADAR/acmmm2019_EADAR.md) 